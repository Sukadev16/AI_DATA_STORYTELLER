# Imarticus Data Science Internship - Assessment (Sample solution)

## Structure
- /code - helper Python files
- /dashboard - Streamlit app
- /report - sample generated report (PDF)
- /assets - saved plots used in the report
- /sample_data.csv - bundled sample CSV used for demo
- README.md - this file

## How to run locally
1. Install dependencies: `pip install pandas numpy matplotlib seaborn streamlit`
2. Run the dashboard: `streamlit run dashboard/app_streamlit.py`